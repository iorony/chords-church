import type { Metadata } from 'next';
import './globals.css';
import Link from 'next/link';
import { createServerSupabaseClient } from '@/lib/supabase/server';
import NavAuthStatus from '@/components/ui/NavAuthStatus';

export const metadata: Metadata = {
  title: 'Cancionero — Acordes para iglesias',
  description: 'Plataforma colaborativa de canciones y acordes para equipos de alabanza'
};

const NAV_LINKS = [
  { href: '/canciones', label: 'Canciones' },
  { href: '/artistas', label: 'Artistas' },
  { href: '/listas', label: 'Mis listas' },
  { href: '/favoritos', label: 'Favoritos' },
  { href: '/canciones/nueva', label: 'Agregar canción' }
];

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const supabase = createServerSupabaseClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  let role: string | null = null;
  if (user) {
    const { data: profile } = await supabase.from('profiles').select('role, display_name').eq('id', user.id).single();
    role = profile?.role ?? null;
  }

  return (
    <html lang="es" suppressHydrationWarning>
      <body className="min-h-screen flex flex-col">
        <header className="border-b border-gray-200 dark:border-gray-800">
          <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
            <Link href="/" className="font-bold text-lg text-primary dark:text-accent-teal">
              🎵 Cancionero
            </Link>
            <nav className="hidden md:flex items-center gap-5 text-sm">
              {NAV_LINKS.map((link) => (
                <Link key={link.href} href={link.href} className="hover:text-primary dark:hover:text-accent-teal">
                  {link.label}
                </Link>
              ))}
              {(role === 'admin' || role === 'moderator') && (
                <Link href="/admin" className="hover:text-primary dark:hover:text-accent-teal">
                  Administración
                </Link>
              )}
            </nav>
            <NavAuthStatus />
          </div>
        </header>
        <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-6">{children}</main>
        <footer className="border-t border-gray-200 dark:border-gray-800 text-center text-xs text-gray-500 py-4">
          Cancionero — plataforma de canciones y acordes para iglesias
        </footer>
      </body>
    </html>
  );
}
