import Link from 'next/link';
import { createServerSupabaseClient } from '@/lib/supabase/server';
import SongCatalogSearch from '@/components/song/SongCatalogSearch';

export default async function SongsPage({ searchParams }: { searchParams: { q?: string } }) {
  const supabase = createServerSupabaseClient();
  const query = searchParams.q?.trim();

  const {
    data: { user }
  } = await supabase.auth.getUser();

  let queryBuilder = supabase
    .from('songs')
    .select('id, title, slug, detected_key, original_key, status, artists(name)')
    .eq('is_deleted', false)
    .order('created_at', { ascending: false })
    .limit(50);

  if (query) {
    queryBuilder = queryBuilder.textSearch('normalized_title', query.split(' ').join(' | '));
  }

  const { data: songs } = await queryBuilder;

  let favoriteSongIds = new Set<string>();

  if (user && songs?.length) {
    const songIds = songs.map((song: any) => song.id);
    const { data: favorites } = await supabase
      .from('song_favorites')
      .select('song_id')
      .eq('user_id', user.id)
      .in('song_id', songIds);

    favoriteSongIds = new Set((favorites ?? []).map((favorite: any) => favorite.song_id));
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">Canciones</h1>
          <p className="mt-1 text-sm text-gray-500">
            Busca automáticamente por título o artista. También puede detectar canciones privadas existentes.
          </p>
        </div>
        <SongCatalogSearch />
      </div>

      {(!songs || songs.length === 0) && (
        <div className="text-sm text-gray-500">
          No se encontraron canciones{query ? ` para "${query}"` : ''}.{' '}
          {query && (
            <Link href={`/buscar/web?q=${encodeURIComponent(query)}`} className="text-primary underline">
              Buscar en la web
            </Link>
          )}
        </div>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {songs?.map((song: any) => (
          <Link
            key={song.id}
            href={`/canciones/${song.slug}`}
            className="border border-gray-200 dark:border-gray-800 rounded-lg p-4 hover:border-primary transition-colors"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="font-medium">{song.title}</div>
              {favoriteSongIds.has(song.id) && (
                <span
                  className="shrink-0 inline-flex items-center gap-1 rounded-full border border-amber-300 bg-amber-50 px-2 py-0.5 text-[11px] font-medium text-amber-700 dark:border-amber-700 dark:bg-amber-950/40 dark:text-amber-300"
                  title="Canción favorita"
                  aria-label="Canción favorita"
                >
                  <span aria-hidden="true">★</span> Favorita
                </span>
              )}
            </div>
            <div className="text-xs text-gray-500 mt-1">{song.artists?.name || 'Artista desconocido'}</div>
            <div className="flex items-center justify-between mt-2">
              <span className="text-xs text-accent-teal">Tono {song.detected_key || song.original_key || '—'}</span>
              {song.status !== 'published' && (
                <span className="text-xs text-gray-400">{song.status}</span>
              )}
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
