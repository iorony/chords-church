import { isChordLine, tokenizeChordLine } from '@/lib/chords/chord-parser';

export interface ChordChartProps {
  content: string;
  fontSizeClass?: string;
  showChords?: boolean;
  showLyrics?: boolean;
}

/**
 * Divide una línea en segmentos alternando espacio en blanco / token,
 * preservando cada espacio exactamente (la fuente es monoespaciada con
 * white-space: pre, así que los espacios se respetan tal cual).
 */

/**
 * Renderiza una línea coloreando SOLO los tokens que realmente son
 * acordes (naranja) o etiquetas de sección inline como "[INTRO]" (azul),
 * dejando cualquier otra palabra, marcador de repetición ("x2") o
 * puntuación en el color de texto normal — nunca se colorea la línea
 * completa.
 */
function renderChordLineTokens(line: string, key: number) {
  const segments = tokenizeChordLine(line);
  return (
    <div key={key}>
      {segments.map((segment, i) => {
        const { value, kind } = segment;
        if (kind === 'whitespace') return <span key={i}>{value}</span>;
        if (kind === 'chord') {
          return (
            <span key={i} className="chord">
              {value}
            </span>
          );
        }
        if (kind === 'section') {
          return (
            <span key={i} className="text-primary dark:text-accent-teal font-semibold">
              {value}
            </span>
          );
        }
        return <span key={i}>{value}</span>;
      })}
    </div>
  );
}

function renderLine(line: string, key: number, showChords: boolean, showLyrics: boolean) {
  const trimmed = line.trim();

  // Línea que es ÚNICAMENTE un encabezado de sección, p.ej. "[CORO]"
  if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
    return (
      <span key={key} className="section-label">
        {trimmed}
      </span>
    );
  }

  if (isChordLine(line)) {
    if (!showChords) return null;
    return renderChordLineTokens(line || '\u00A0', key);
  }

  if (!showLyrics && trimmed !== '') return null;

  return <div key={key}>{line || '\u00A0'}</div>;
}

/**
 * Muestra el contenido de una canción (letra + acordes) preservando la
 * alineación exacta con fuente monoespaciada. Solo los tokens que son
 * acordes se resaltan con un color distintivo; las etiquetas de sección
 * (entre corchetes) se muestran en azul, e incluso si comparten línea
 * con acordes (p.ej. "[INTRO] Bm A x2") cada parte queda bien
 * identificada por separado.
 */
export default function ChordChart({ content, fontSizeClass = 'text-base', showChords = true, showLyrics = true }: ChordChartProps) {
  const lines = content.split('\n');
  return (
    <div className={`song-content ${fontSizeClass}`}>
      {lines.map((line, i) => renderLine(line, i, showChords, showLyrics))}
    </div>
  );
}
