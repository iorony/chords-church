'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function NavAuthStatus() {
  const supabase = createClient();
  const router = useRouter();
  const [email, setEmail] = useState<string | null | undefined>(undefined);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setEmail(session?.user?.email ?? null);
    });
    return () => sub.subscription.unsubscribe();
  }, [supabase]);

  if (email === undefined) return <div className="w-20" />;

  if (!email) {
    return (
      <div className="flex items-center gap-3 text-sm">
        <Link href="/login" className="hover:text-primary">
          Iniciar sesión
        </Link>
        <Link
          href="/registro"
          className="bg-primary text-white px-3 py-1.5 rounded-md hover:bg-primary-light"
        >
          Registrarse
        </Link>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3 text-sm">
      <Link href="/perfil" className="hover:text-primary">
        {email}
      </Link>
      <button
        onClick={async () => {
          await supabase.auth.signOut();
          router.refresh();
        }}
        className="text-gray-500 hover:text-danger"
      >
        Salir
      </button>
    </div>
  );
}
