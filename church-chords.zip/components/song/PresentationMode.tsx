'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { transposeSongContent, semitoneDifference, keyToIndex, ALL_KEYS_GENERAL } from '@/lib/chords/transposition';
import { buildSections } from '@/lib/chords/structure-parser';
import type { SongSection } from '@/lib/chords/types';
import ChordChart from './ChordChart';

export interface PresentationSong {
  title: string;
  artist?: string;
  baseKey: string;
  selectedKey: string;
  capo: number;
  content: string;
}

export interface PresentationModeProps {
  songs: PresentationSong[];
}

type SectionPage = SongSection[][];

const MIN_FONT_REM = 0.42;
const MAX_FONT_REM = 4;

function visualLineLength(line: string): number {
  // Las tabulaciones ocupan varias columnas en una fuente monoespaciada.
  return line.replace(/\t/g, '    ').length;
}

function longestSectionLine(sections: SongSection[]): number {
  return sections.reduce((largest, section) => {
    const labelLength = visualLineLength(`[${section.label}]`);
    const contentLength = section.content
      .split('\n')
      .reduce((max, line) => Math.max(max, visualLineLength(line)), 0);
    return Math.max(largest, labelLength, contentLength);
  }, 1);
}

function estimateSectionLines(section: SongSection): number {
  const contentLines = Math.max(1, section.content.split('\n').length);

  // Encabezado + separación inferior. No contamos envolturas porque en modo
  // presentación conservamos cada línea completa para no perder la alineación
  // entre acordes y letra.
  return contentLines + 2.4;
}

function chooseColumnCount(width: number): number {
  if (width < 700) return 1;
  if (width < 1180) return 2;
  return 3;
}

function buildSectionPages(
  sections: SongSection[],
  viewportWidth: number,
  viewportHeight: number,
  requestedFontRem: number
): { pages: SectionPage[]; fontRem: number; columns: number } {
  const columns = chooseColumnCount(viewportWidth);
  const horizontalPadding = viewportWidth < 700 ? 24 : 48;
  const gap = viewportWidth < 700 ? 12 : 20;
  const columnWidth = Math.max(180, (viewportWidth - horizontalPadding - gap * (columns - 1)) / columns);
  const reservedHeight = viewportWidth < 700 ? 132 : 142;
  const availableHeight = Math.max(180, viewportHeight - reservedHeight);

  let fontRem = Math.min(MAX_FONT_REM, Math.max(MIN_FONT_REM, requestedFontRem));

  // En móvil, el zoom se calcula también según la línea más larga de la canción.
  // Así cada renglón se mantiene completo, sin desplazamiento horizontal y sin
  // romper la alineación monoespaciada entre acordes y sílabas.
  if (viewportWidth < 700 && sections.length > 0) {
    const longestLine = longestSectionLine(sections);
    const safeColumnWidth = Math.max(120, columnWidth - 4);
    const widthFitRem = safeColumnWidth / (Math.max(longestLine, 1) * 0.62 * 16);
    fontRem = Math.min(fontRem, Math.max(MIN_FONT_REM, widthFitRem));
  }

  // Si una sección individual no cabe verticalmente, reducimos automáticamente
  // el tamaño hasta que pueda mostrarse completa en una sola columna.
  while (fontRem > MIN_FONT_REM) {
    const fontPx = fontRem * 16;
    const capacity = availableHeight / (fontPx * 1.48);
    const largest = sections.reduce(
      (max, section) => Math.max(max, estimateSectionLines(section)),
      0
    );
    if (largest <= capacity) break;
    fontRem = Math.max(MIN_FONT_REM, Number((fontRem - 0.04).toFixed(2)));
  }

  const fontPx = fontRem * 16;
  const capacity = availableHeight / (fontPx * 1.48);
  const pages: SectionPage[] = [];
  let page: SectionPage = Array.from({ length: columns }, () => []);
  let columnIndex = 0;
  let used = 0;

  const flushPage = () => {
    if (page.some((column) => column.length > 0)) pages.push(page);
    page = Array.from({ length: columns }, () => []);
    columnIndex = 0;
    used = 0;
  };

  for (const section of sections) {
    const sectionSize = estimateSectionLines(section);

    // Nunca cortamos una sección entre columnas. Si no cabe en la columna
    // actual, pasa completa a la siguiente; si ya no hay columna, a otra página.
    if (page[columnIndex].length > 0 && used + sectionSize > capacity) {
      columnIndex += 1;
      used = 0;
    }

    if (columnIndex >= columns) flushPage();

    page[columnIndex].push(section);
    used += sectionSize;
  }

  flushPage();
  return { pages: pages.length ? pages : [Array.from({ length: columns }, () => [])], fontRem, columns };
}

export default function PresentationMode({ songs }: PresentationModeProps) {
  const router = useRouter();
  const [songIndex, setSongIndex] = useState(0);
  const [pageIndex, setPageIndex] = useState(0);
  const [fontSize, setFontSize] = useState(1.5);
  const [dark, setDark] = useState(true);
  const [showKeyPicker, setShowKeyPicker] = useState(false);
  const [semitoneOverride, setSemitoneOverride] = useState(0);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [viewport, setViewport] = useState({ width: 1280, height: 720 });
  const hideTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const openPreviousSongAtLastPage = useRef(false);

  // Puede ocurrir que la presentación se abra antes de que la lista termine
  // de cargarse, o que alguna canción antigua no tenga baseKey/selectedKey.
  // Normalizamos los datos para evitar errores de runtime.
  const rawSong = songs[songIndex] ?? songs[0];
  const song: PresentationSong = {
    title: rawSong?.title?.trim() || 'Canción sin título',
    artist: rawSong?.artist?.trim() || 'Artista desconocido',
    baseKey: rawSong?.baseKey?.trim() || 'C',
    selectedKey: rawSong?.selectedKey?.trim() || rawSong?.baseKey?.trim() || 'C',
    capo: Number.isFinite(rawSong?.capo) ? rawSong.capo : 0,
    content: rawSong?.content || ''
  };
  const hasSongs = songs.length > 0;
  const isMinorKey = /m$/i.test(song.baseKey);
  const semitones = semitoneOverride || semitoneDifference(song.baseKey, song.selectedKey);
  const transposedContent = transposeSongContent(song.content, { semitones });
  const currentKey =
    ALL_KEYS_GENERAL[((keyToIndex(song.baseKey) + semitones) % 12 + 12) % 12] + (isMinorKey ? 'm' : '');

  const sections = useMemo(() => buildSections(transposedContent), [transposedContent]);
  const layout = useMemo(
    () => buildSectionPages(sections, viewport.width, viewport.height, fontSize),
    [sections, viewport, fontSize]
  );

  const currentPage = layout.pages[Math.min(pageIndex, layout.pages.length - 1)] ?? Array.from({ length: layout.columns }, () => []);

  const nextSong = useCallback(() => {
    setSongIndex((i) => Math.min(i + 1, songs.length - 1));
    setPageIndex(0);
  }, [songs.length]);

  const prevSong = useCallback(() => {
    setSongIndex((i) => Math.max(i - 1, 0));
    setPageIndex(0);
  }, []);

  const nextPage = useCallback(() => {
    // No hacemos setSongIndex dentro del actualizador de setPageIndex.
    // React puede ejecutar los actualizadores funcionales más de una vez en
    // desarrollo (Strict Mode), lo que provocaba saltos de dos canciones y que
    // solo se mostraran las posiciones impares.
    if (pageIndex < layout.pages.length - 1) {
      setPageIndex(pageIndex + 1);
      return;
    }

    if (songIndex < songs.length - 1) {
      setPageIndex(0);
      setSongIndex(songIndex + 1);
    }
  }, [pageIndex, layout.pages.length, songIndex, songs.length]);

  const prevPage = useCallback(() => {
    if (pageIndex > 0) {
      setPageIndex(pageIndex - 1);
      return;
    }

    if (songIndex > 0) {
      openPreviousSongAtLastPage.current = true;
      setPageIndex(0);
      setSongIndex(songIndex - 1);
    }
  }, [pageIndex, songIndex]);

  useEffect(() => {
    const updateViewport = () => setViewport({ width: window.innerWidth, height: window.innerHeight });
    updateViewport();
    window.addEventListener('resize', updateViewport);
    return () => window.removeEventListener('resize', updateViewport);
  }, []);

  useEffect(() => {
    setSemitoneOverride(0);
    if (!openPreviousSongAtLastPage.current) setPageIndex(0);
  }, [songIndex]);

  useEffect(() => {
    if (openPreviousSongAtLastPage.current) {
      openPreviousSongAtLastPage.current = false;
      setPageIndex(Math.max(0, layout.pages.length - 1));
      return;
    }
    if (pageIndex >= layout.pages.length) setPageIndex(Math.max(0, layout.pages.length - 1));
  }, [layout.pages.length, pageIndex, songIndex]);

  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      switch (e.key) {
        case 'ArrowRight':
        case 'ArrowDown':
        case 'PageDown':
        case ' ':
          e.preventDefault();
          nextPage();
          break;
        case 'ArrowLeft':
        case 'ArrowUp':
        case 'PageUp':
          e.preventDefault();
          prevPage();
          break;
        case '+':
        case '=':
          setFontSize((f) => Math.min(f + 0.1, MAX_FONT_REM));
          break;
        case '-':
          setFontSize((f) => Math.max(f - 0.1, MIN_FONT_REM));
          break;
        case 'd':
        case 'D':
          setDark((d) => !d);
          break;
        case 't':
        case 'T':
          setShowKeyPicker((v) => !v);
          break;
        case 'f':
        case 'F':
          document.documentElement.requestFullscreen?.().catch(() => {});
          break;
        case 'Escape':
          if (document.fullscreenElement) {
            document.exitFullscreen?.().catch(() => {});
          } else {
            router.back();
          }
          break;
      }
    }
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [nextPage, prevPage, nextSong, prevSong, router]);

  function resetControlsTimer() {
    setControlsVisible(true);
    if (hideTimeout.current) clearTimeout(hideTimeout.current);
    hideTimeout.current = setTimeout(() => setControlsVisible(false), 4000);
  }

  useEffect(() => {
    resetControlsTimer();
    return () => {
      if (hideTimeout.current) clearTimeout(hideTimeout.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      className={`fixed inset-0 z-50 overflow-hidden ${dark ? 'bg-black text-white' : 'bg-white text-black'}`}
      style={{ height: '100dvh' }}
      onMouseMove={resetControlsTimer}
      onClick={resetControlsTimer}
      onTouchStart={resetControlsTimer}
    >
      <div
        className={`absolute top-0 left-0 right-0 z-20 flex items-center justify-between gap-2 px-3 sm:px-4 py-2 text-xs sm:text-sm transition-opacity ${
          controlsVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
        } ${dark ? 'bg-black/90' : 'bg-white/95'} border-b ${dark ? 'border-gray-800' : 'border-gray-200'}`}
      >
        <div className="flex min-w-0 items-center gap-2 sm:gap-3">
          <button onClick={() => router.back()} className="shrink-0 opacity-70 hover:opacity-100">
            ✕ Salir
          </button>
          <span className="truncate opacity-70">
            {hasSongs ? songIndex + 1 : 0}/{songs.length}: {song.title}
          </span>
        </div>
        <div className="flex shrink-0 items-center gap-2 sm:gap-3">
          <button onClick={() => setShowKeyPicker((v) => !v)} className="opacity-70 hover:opacity-100">
            {currentKey} <span className="hidden sm:inline">(T)</span>
          </button>
          <button onClick={() => setFontSize((f) => Math.max(f - 0.1, MIN_FONT_REM))} aria-label="Reducir texto">
            A−
          </button>
          <button onClick={() => setFontSize((f) => Math.min(f + 0.1, MAX_FONT_REM))} aria-label="Aumentar texto">
            A+
          </button>
          <button onClick={() => setDark((d) => !d)} className="opacity-70 hover:opacity-100">
            {dark ? '☀' : '🌙'}
          </button>
        </div>
      </div>

      {showKeyPicker && (
        <div className="absolute top-12 right-3 sm:right-4 z-30 max-w-[calc(100vw-1.5rem)] bg-gray-900 text-white rounded-lg p-3 grid grid-cols-4 gap-2 text-sm shadow-xl">
          {ALL_KEYS_GENERAL.map((k) => (
            <button
              key={k}
              onClick={() => {
                setSemitoneOverride(semitoneDifference(song.baseKey, k));
                setShowKeyPicker(false);
              }}
              className={`px-2 py-1 rounded ${k + (isMinorKey ? 'm' : '') === currentKey ? 'bg-primary' : 'hover:bg-gray-700'}`}
            >
              {k}
              {isMinorKey ? 'm' : ''}
            </button>
          ))}
        </div>
      )}

      <main className="absolute inset-x-0 top-11 bottom-14 sm:top-12 sm:bottom-14 overflow-hidden px-3 sm:px-6 py-2 sm:py-3">
        {!hasSongs ? (
          <div className="flex h-full items-center justify-center text-center opacity-70">
            No hay canciones disponibles para presentar.
          </div>
        ) : (
        <div className="flex h-full min-h-0 flex-col">
          <div className="mb-1.5 flex shrink-0 items-start justify-between gap-3">
            <div className="min-w-0">
              <h1
                className="truncate font-bold opacity-90"
                style={{ fontSize: `${Math.max(1, layout.fontRem * 1.12)}rem` }}
              >
                {song.title}
              </h1>
              <p className="truncate text-xs sm:text-sm opacity-65">
                {song.artist} <span className="mx-1.5 opacity-60">•</span> Tono: {currentKey}
              </p>
            </div>
            <span className="shrink-0 pt-1 text-xs opacity-55">
              Página {pageIndex + 1}/{layout.pages.length}
            </span>
          </div>

          <div
            className="grid min-h-0 flex-1 gap-3 sm:gap-5 overflow-hidden"
            style={{ gridTemplateColumns: `repeat(${layout.columns}, minmax(0, 1fr))` }}
          >
            {currentPage.map((column, columnNumber) => (
              <div
                key={columnNumber}
                className={`min-w-0 overflow-hidden ${columnNumber > 0 ? `border-l pl-3 sm:pl-5 ${dark ? 'border-gray-800' : 'border-gray-200'}` : ''}`}
              >
                <div className="flex h-full min-h-0 flex-col justify-start gap-[0.55em] overflow-hidden" style={{ fontSize: `${layout.fontRem}rem`, lineHeight: viewport.width < 700 ? 1.34 : 1.45 }}>
                  {column.map((section) => (
                    <section key={`${section.order}-${section.label}`} className="shrink-0 break-inside-avoid overflow-hidden">
                      <div className="mb-[0.18em] font-mono font-semibold text-primary dark:text-accent-teal">
                        [{section.label}]
                      </div>
                      <ChordChart content={section.content} fontSizeClass="" />
                    </section>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
        )}
      </main>

      <div
        className={`absolute bottom-0 left-0 right-0 z-20 flex items-center justify-between gap-3 px-3 sm:px-5 py-2 text-xs sm:text-sm transition-opacity ${
          controlsVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
        } ${dark ? 'bg-black/90' : 'bg-white/95'} border-t ${dark ? 'border-gray-800' : 'border-gray-200'}`}
      >
        <button
          onClick={prevPage}
          disabled={!hasSongs || (songIndex === 0 && pageIndex === 0)}
          className="rounded px-2 py-1 opacity-80 hover:opacity-100 disabled:opacity-30"
        >
          ← Anterior
        </button>
        <span className="hidden min-w-0 truncate opacity-50 sm:block">
          ← → página · ↑ ↓ canción · +/− tamaño · T tono · F pantalla completa
        </span>
        <button
          onClick={nextPage}
          disabled={!hasSongs || (songIndex === songs.length - 1 && pageIndex === layout.pages.length - 1)}
          className="rounded px-2 py-1 opacity-80 hover:opacity-100 disabled:opacity-30"
        >
          Siguiente →
        </button>
      </div>
    </div>
  );
}
