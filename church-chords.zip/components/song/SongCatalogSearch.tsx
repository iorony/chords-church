'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';

type SearchSong = {
  id: string;
  title: string;
  slug: string;
  artist: string | null;
  detected_key: string | null;
  original_key: string | null;
  visibility: 'public' | 'private';
  is_owner: boolean;
  shared_list_access: boolean;
  can_open_directly: boolean;
};

export default function SongCatalogSearch() {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [songs, setSongs] = useState<SearchSong[]>([]);
  const [loading, setLoading] = useState(false);
  const [openingId, setOpeningId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const requestId = useRef(0);

  useEffect(() => {
    const value = query.trim();
    if (value.length < 2) {
      setSongs([]);
      setError(null);
      setLoading(false);
      return;
    }

    const currentRequest = ++requestId.current;
    const timer = window.setTimeout(async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await fetch(`/api/songs/search?q=${encodeURIComponent(value)}`, {
          cache: 'no-store'
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'No se pudo realizar la búsqueda.');
        if (currentRequest === requestId.current) setSongs(data.songs ?? []);
      } catch (searchError) {
        if (currentRequest === requestId.current) {
          setSongs([]);
          setError(searchError instanceof Error ? searchError.message : 'No se pudo realizar la búsqueda.');
        }
      } finally {
        if (currentRequest === requestId.current) setLoading(false);
      }
    }, 300);

    return () => window.clearTimeout(timer);
  }, [query]);

  async function openSong(song: SearchSong) {
    setOpeningId(song.id);
    setError(null);

    try {
      if (!song.can_open_directly && song.visibility === 'private') {
        const response = await fetch('/api/songs/duplicates', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            title: song.title,
            artist: song.artist || 'Artista desconocido',
            content: '',
            promote: true
          })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'No se pudo habilitar la canción existente.');
        const resolved = data.duplicates?.[0];
        router.push(`/canciones/${resolved?.slug || song.slug}`);
      } else {
        router.push(`/canciones/${song.slug}`);
      }
      router.refresh();
    } catch (openError) {
      setError(openError instanceof Error ? openError.message : 'No se pudo abrir la canción.');
    } finally {
      setOpeningId(null);
    }
  }

  return (
    <div className="relative w-full max-w-xl">
      <input
        type="search"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Buscar por canción o artista..."
        className="w-full rounded-md border border-gray-300 bg-transparent px-3 py-2 dark:border-gray-700"
        aria-label="Buscar canciones"
        autoComplete="off"
      />

      {loading && <div className="mt-2 text-xs text-gray-500">Buscando canciones...</div>}
      {error && <div className="mt-2 text-sm text-red-600">{error}</div>}

      {query.trim().length >= 2 && !loading && !error && (
        <div className="absolute left-0 right-0 top-full z-30 mt-2 max-h-96 overflow-y-auto rounded-lg border border-gray-200 bg-white shadow-xl dark:border-gray-700 dark:bg-gray-950">
          {songs.length === 0 ? (
            <div className="p-4 text-sm text-gray-500">No se encontraron canciones.</div>
          ) : (
            songs.map((song) => (
              <div key={song.id} className="flex items-center justify-between gap-4 border-b border-gray-100 p-3 last:border-b-0 dark:border-gray-800">
                <div className="min-w-0">
                  <div className="truncate font-medium">{song.title}</div>
                  <div className="truncate text-xs text-gray-500">
                    {song.artist || 'Artista desconocido'} · Tono {song.detected_key || song.original_key || '—'}
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1">
                    <span className={`rounded-full px-2 py-0.5 text-[10px] ${song.visibility === 'private' ? 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300' : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300'}`}>
                      {song.visibility === 'private' ? 'Privada' : 'Pública'}
                    </span>
                    {song.shared_list_access && (
                      <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[10px] text-blue-700 dark:bg-blue-950/40 dark:text-blue-300">Lista compartida</span>
                    )}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => openSong(song)}
                  disabled={openingId === song.id}
                  className="shrink-0 rounded-md border border-primary px-3 py-1.5 text-sm text-primary disabled:opacity-50"
                >
                  {openingId === song.id
                    ? 'Abriendo...'
                    : !song.can_open_directly && song.visibility === 'private'
                      ? 'Usar existente'
                      : 'Abrir'}
                </button>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
