'use client';

import { useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';

export interface AdminSong {
  id: string;
  title: string;
  slug: string;
  status: string;
  visibility: string;
  is_deleted: boolean;
  artists?: { name: string } | null;
}

export default function AdminSongsTable({ songs: initial }: { songs: AdminSong[] }) {
  const supabase = createClient();
  const [songs, setSongs] = useState(initial);

  async function toggleDeactivate(song: AdminSong) {
    const newDeleted = !song.is_deleted;
    await supabase.from('songs').update({ is_deleted: newDeleted }).eq('id', song.id);
    setSongs(songs.map((s) => (s.id === song.id ? { ...s, is_deleted: newDeleted } : s)));
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr className="text-left border-b border-gray-200 dark:border-gray-800">
            <th className="py-2 pr-4">Título</th>
            <th className="py-2 pr-4">Artista</th>
            <th className="py-2 pr-4">Estado</th>
            <th className="py-2 pr-4">Visibilidad</th>
            <th className="py-2 pr-4">Acciones</th>
          </tr>
        </thead>
        <tbody>
          {songs.map((s) => (
            <tr key={s.id} className="border-b border-gray-100 dark:border-gray-900">
              <td className="py-2 pr-4">
                <Link href={`/canciones/${s.slug}`} className="hover:text-primary">
                  {s.title}
                </Link>
              </td>
              <td className="py-2 pr-4 text-gray-500">{s.artists?.name || '—'}</td>
              <td className="py-2 pr-4">{s.status}</td>
              <td className="py-2 pr-4">{s.visibility === 'private' ? 'Privada' : 'Pública'}</td>
              <td className="py-2 pr-4">
                <button onClick={() => toggleDeactivate(s)} className="text-danger underline text-xs">
                  {s.is_deleted ? 'Restaurar' : 'Desactivar'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
